package com.telkomuniversity.emonitoring.Util;

public class ServerAPI {

    // ID DATABASE
    public static final String URL_REGIST       = "http://192.168.1.9/emonitoring/android/logindata/register.php";
    public static final String URL_LOGIN        = "http://192.168.1.9/emonitoring/android/logindata/login.php";

    // RELAY
    public static final String URL_VIEW         = "http://192.168.1.9/emonitoring/android/relaystatusandroid/view_data.php";
    public static final String URL_UPDATE       = "http://192.168.1.9/emonitoring/android/relaystatusandroid/update_data.php";

    // MODBUS
    public static final String LAST_MODBUS      = "http://192.168.1.9/emonitoring/android/devicedata/last_modbus.php";

    // TOKEN
    public static final String URL_TOKEN_UPDATE = "http://192.168.1.9/emonitoring/android/androidupdatetoken/update_data.php";
    public static final String URL_TOKEN_VIEW   = "http://192.168.1.9/emonitoring/android/androidupdatetoken/view_data.php";

    // SENSOR, LAST DATA ONLY
    public static final String LAST_DEVICE1     = "http://192.168.1.9/emonitoring/android/devicedata/last_data1.php";
    public static final String LAST_DEVICE2     = "http://192.168.1.9/emonitoring/android/devicedata/last_data2.php";
    public static final String LAST_DEVICE3     = "http://192.168.1.9/emonitoring/android/devicedata/last_data3.php";
    public static final String LAST_DEVICE4     = "http://192.168.1.9/emonitoring/android/devicedata/last_data4.php";
}