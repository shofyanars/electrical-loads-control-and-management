package com.telkomuniversity.emonitoring;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

public class HomeMenu extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private TextView    nama;
    private Button      btn_logout_home, btn_token_home, btn_mode_home,btn_modee_home;
    private Switch      mSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        getSupportActionBar().hide();

        nama            = findViewById(R.id.nama);
        btn_mode_home   = findViewById(R.id.btn_setmode_home);
        btn_token_home  = findViewById(R.id.btn_settoken_home);
        btn_logout_home = findViewById(R.id.btn_logout_home);
        btn_modee_home  = findViewById(R.id.btn_setmodee_home);

        Intent intent         = getIntent();
        String extraNama    = intent.getStringExtra("nama");

        nama.setText(extraNama);

        btn_modee_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent move = new Intent(HomeMenu.this, Mode_automatic.class);
                startActivity(move);
            }
        });

        btn_mode_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent move = new Intent(HomeMenu.this, mode_electricity.class);
                startActivity(move);
            }
        });

        btn_token_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent move = new Intent(HomeMenu.this, input_token.class);
                startActivity(move);
            }
        });

        btn_logout_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent move = new Intent(HomeMenu.this, LoginActivity.class);
                startActivity(move);
                finish();
            }
        });
    }
}
