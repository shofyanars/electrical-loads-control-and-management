package com.telkomuniversity.emonitoring;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.support.v4.app.NotificationCompat;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.telkomuniversity.emonitoring.Util.AppController;
import com.telkomuniversity.emonitoring.Util.ServerAPI;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AutomaticMode extends BroadcastReceiver {

    String NOTIFICATION_CHANNEL_ID = "emonitoring";
    String NOTIFICATION_CHANNEL_NAME = "warning";
    public String Message;
    String id, status, priority, nama;

    @Override
    public void onReceive(Context context, Intent intent) {

        Intent alarmIntent11 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent12 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent13 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent14 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent15 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent21 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent22 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent23 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent24 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent25 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent31 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent32 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent33 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent34 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent35 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent41 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent42 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent43 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent44 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        Intent alarmIntent45 = new Intent(context, AutomaticMode.class);
        Message    = intent.getStringExtra("Message");
        id         = intent.getStringExtra("id");
        nama       = intent.getStringExtra("name");
        status     = intent.getStringExtra("status");
        priority   = intent.getStringExtra("priority");

        if(id != null && nama != null && status != null && priority != null){
            updateData(id,status, priority, nama);
        }

        //kirim notifikasi
        sendNotification(context, intent);
    }
    //handle notification
    private void sendNotification(Context context, Intent intent) {

        SimpleDateFormat sdf = new SimpleDateFormat("dd MM yyyy HH:mm:ss");
        String datetimex = sdf.format(new Date());
        String notif_title = "e-monitoring > " + Message;
        String notif_content = "Notif time "+datetimex;
        NotificationManager alarmNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent newIntent = new Intent(context,MainActivity.class);
        newIntent.putExtra("notifkey", "notifvalue");
        PendingIntent contentIntent = PendingIntent.getActivity(context, 0, newIntent, PendingIntent.FLAG_UPDATE_CURRENT);


        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel mChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, NOTIFICATION_CHANNEL_NAME, importance);
        alarmNotificationManager.createNotificationChannel(mChannel);

        //Buat notification
        NotificationCompat.Builder alamNotificationBuilder = new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID);
        alamNotificationBuilder.setContentTitle(notif_title);
        alamNotificationBuilder.setSmallIcon(R.mipmap.ic_launcher);
        alamNotificationBuilder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
        alamNotificationBuilder.setContentText(notif_content);
        alamNotificationBuilder.setAutoCancel(true);
        alamNotificationBuilder.setContentIntent(contentIntent);
        //Tampilkan notifikasi
        alarmNotificationManager.notify(1, alamNotificationBuilder.build());
    }

    private void updateData(String id, String status, String priority, String nama)
    {
        StringRequest updateReq = new StringRequest(Request.Method.POST, ServerAPI.URL_UPDATE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try
                        {
                            JSONObject res = new JSONObject(response);
                        }
                        catch(JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> map = new HashMap<>();
                map.put("id", id);
                map.put("nama", nama);
                map.put("status", status);
                map.put("priority", priority);
                return map;
            }
        };
        AppController.getInstance().addToRequestQueue(updateReq);
    }
}