package com.telkomuniversity.emonitoring;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.telkomuniversity.emonitoring.Util.AppController;
import com.telkomuniversity.emonitoring.Util.ServerAPI;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.Reference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class mode_electricity_update extends AppCompatActivity {

    TextView        tvid, tvstatus, tvpriority;
    EditText        etnama;
    Switch          mSwitch;
    Button          update, cancel;
    String          statusdevice, prioritydevice, iddevice;

    private Spinner     spinner;
    private String[]    prioritySelect= {
            "0",
            "1",
            "2",
            "3",
            "4",
    };

    long startTime=0L, timeInMilliseconds=0L, timeSwapBuff=0L, updateTime=0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode_electricity_update);

        getSupportActionBar().hide();

        Intent  intent            = getIntent();
        String  intent_id         = intent.getStringExtra("id");
        String  intent_nama       = intent.getStringExtra("nama");
        String  intent_status     = intent.getStringExtra("status");
        String  intent_priority   = intent.getStringExtra("priority");

        tvid        = (TextView) findViewById(R.id.tv_relayid_set);
        etnama      = (EditText) findViewById(R.id.et_nama_mode);
        tvstatus    = (TextView) findViewById(R.id.tv_relaystatus_set);
        tvpriority  = (TextView) findViewById(R.id.tv_relaypriority_set);

        mSwitch     = (Switch) findViewById(R.id.switch_update);
        spinner     = (Spinner) findViewById(R.id.spinner_priority);

        cancel      = (Button)   findViewById(R.id.btn_cancel_update);
        update      = (Button)   findViewById(R.id.btn_update_update);

        iddevice    = intent_id;
        tvid.setText("Device id         : " + intent_id);

        if (intent_status.equals("0")){
            tvstatus.setText("Device status : off");
            statusdevice = "0";
        }
        else{
            tvstatus.setText("Device status : on");
            statusdevice = "1";
        }

        etnama.setText(intent_nama);

        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, prioritySelect);
        spinner.setAdapter(adapter);

        // mengeset listener untuk mengetahui saat item dipilih
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // memunculkan toast + value Spinner yang dipilih (diambil dari adapter)
                Toast.makeText(mode_electricity_update.this, "Selected "+ adapter.getItem(i), Toast.LENGTH_SHORT).show();
                prioritydevice  = adapter.getItem(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTime   = SystemClock.uptimeMillis();
                updateData();
                timeInMilliseconds = SystemClock.uptimeMillis()-startTime;
                timeInMilliseconds = timeInMilliseconds/1000;
                Log.d("time", "0.0"+timeInMilliseconds+" timer stopwatch stopped ==========================================================================================");
                Intent move = new Intent(mode_electricity_update.this, mode_electricity.class);
                startActivity(move);
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent move = new Intent(mode_electricity_update.this, mode_electricity.class);
                startActivity(move);
            }
        });

        mSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mSwitch.isChecked())
                {
                    tvstatus.setText("Device status : off");
                    statusdevice = "0";
                }
                else
                {
                    tvstatus.setText("Device status : on");
                    statusdevice = "1";
                }
            }
        });
    }


    private void updateData()
    {
        StringRequest updateReq = new StringRequest(Request.Method.POST, ServerAPI.URL_UPDATE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try
                        {
                            JSONObject res = new JSONObject(response);
                            Toast.makeText(mode_electricity_update.this, "Pesan : " + res.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                        catch(JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mode_electricity_update.this, "Pesan : Gagal update data!", Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> map = new HashMap<>();
                map.put("id", iddevice);
                map.put("nama", etnama.getText().toString());
                map.put("status", statusdevice);
                map.put("priority", prioritydevice);
                return map;
            }
        };
        AppController.getInstance().addToRequestQueue(updateReq);
    }
}
