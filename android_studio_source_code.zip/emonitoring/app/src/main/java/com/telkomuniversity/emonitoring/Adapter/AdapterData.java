package com.telkomuniversity.emonitoring.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.telkomuniversity.emonitoring.Model.ModelData;
import com.telkomuniversity.emonitoring.R;
import com.telkomuniversity.emonitoring.mode_electricity_update;

import java.util.List;

public class AdapterData extends RecyclerView.Adapter<AdapterData.HolderData> {

    // ArrayList untuk menampung data
    private List<ModelData> mItems;
    private Context         context;

    public AdapterData (Context context, List<ModelData> items)
    {
        this.mItems  = items;
        this.context = context;
    }

    // ke-3 method ini didapat setelah memasukkan parameter AdapterData.HolderData pada RecyclerView.Adapter<>
    // kemudian muncul error > insert method, @nonnull dihapus
    @Override
    public HolderData onCreateViewHolder(ViewGroup parent, int i) {
        // parameter viewgrup dirubah ke parent
        // digunakan untuk menghubungkan ke layout
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_row,parent,false);
        HolderData holderData = new HolderData(layout);
        return holderData;
    }

    @Override
    public void onBindViewHolder(HolderData holder, int position) {
        // parameter holderData dirubah ke holder
        ModelData md =  mItems.get(position);

        holder.tvnama.setText(md.getNama());
        holder.tvid.setText(md.getId());
        holder.tvstatus.setText(md.getStatus());
        holder.tvpriority.setText(md.getPriority());

        holder.md = md;
    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    // class holder
    class HolderData extends RecyclerView.ViewHolder
    {
        TextView tvnama, tvid, tvstatus, tvpriority;
        ModelData md;

        public HolderData (View view)
        {
            super(view);

            tvnama      = (TextView) view.findViewById(R.id.tvnama);
            tvid        = (TextView) view.findViewById(R.id.tvid);
            tvstatus    = (TextView) view.findViewById(R.id.tvstatus);
            tvpriority  = (TextView) view.findViewById(R.id.tvpriority);


            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, mode_electricity_update.class);
                    intent.putExtra("update", 1);
                    intent.putExtra("id",md.getId());
                    intent.putExtra("nama",md.getNama());
                    intent.putExtra("status",md.getStatus());;
                    intent.putExtra("priority",md.getPriority());

                    context.startActivity(intent);
                }
            });
        }
    }
}
