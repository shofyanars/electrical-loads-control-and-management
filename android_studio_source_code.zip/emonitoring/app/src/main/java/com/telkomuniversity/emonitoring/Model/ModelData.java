package com.telkomuniversity.emonitoring.Model;


// mengacu dari data yang diambil dari mysql, meyesuaikan tipe datanya

public class ModelData {

    String nama, id, status, priority;

    public ModelData(){}

    // constructor, diambil dari atas, cara : (alt + insert)
    public ModelData(String nama, String id, String status, String priority) {
        this.nama = nama;
        this.id = id;
        this.status = status;
        this.priority = priority;
    }

    // ( alt + inser ) > getter and setter > select all
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }
}
