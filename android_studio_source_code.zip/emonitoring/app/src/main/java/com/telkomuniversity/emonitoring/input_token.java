package com.telkomuniversity.emonitoring;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.telkomuniversity.emonitoring.Util.AppController;
import com.telkomuniversity.emonitoring.Util.ServerAPI;

import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Spliterator;

public class input_token extends AppCompatActivity {

    private TextView    tv_usage_daily, tv_usage_now;
    private EditText    inputToken;
    private Button      btn_set_token, btn_back_token;
    public  static String  month;
    public static int       bulan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_token);

        getSupportActionBar().hide();
        getBulan();

        tv_usage_now    = findViewById(R.id.tv_usage_token);
        tv_usage_daily   = findViewById(R.id.tv_usage_daily);
        inputToken      = findViewById(R.id.et_monthly_token);
        btn_set_token   = findViewById(R.id.btn_set_token);
        btn_back_token  = findViewById(R.id.btn_back_token);

        btn_set_token.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String  mInput   = inputToken.getText().toString().trim();

                if (!mInput.isEmpty())
                {
                    tv_usage_now.setText("Token bulanan   : " + inputToken.getText().toString());
                    Double token = Double.valueOf(inputToken.getText().toString());
                    Double hari = token/30;
                    tv_usage_daily.setText("Token harian       : " + hari);
                    updateToken();
                }
                else
                {
                    inputToken.setError("Please insert token!");
                }


            }
        });

        btn_back_token.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(input_token.this, HomeMenu.class);
                startActivity(intent);
            }
        });
    }

    private void loadToken()
    {
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.URL_TOKEN_VIEW, null,
                response -> {
                    Log.d("volley", "response : " + response.toString());

                    //TampilDataToken toks = new TampilDataToken();

                    for(int i = 0; i < response.length(); i++)
                    {
                        try
                        {
                            JSONObject data = response.getJSONObject(i);

                            String xx       = data.getString("id");
                            int    id       = Integer.parseInt(xx);
                            String yy       = data.getString("token");
                            int    token    = Integer.parseInt(yy);
                            String zz       = data.getString("sisa");
                            int    sisa     = Integer.parseInt(zz);
                            String mode       = data.getString("mode");

                            //toks.isiData(id,token,sisa, mode);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    // toks.showData();
                },
                error -> Log.d("volley", "error : " + error.getMessage()));
        AppController.getInstance().addToRequestQueue(reqData);
    }

    private void updateToken()
    {
        StringRequest updateReq = new StringRequest(Request.Method.POST, ServerAPI.URL_TOKEN_UPDATE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try
                        {
                            JSONObject res = new JSONObject(response);
                            Toast.makeText(input_token.this, "Pesan : " + res.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                        catch(JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(input_token.this, "Pesan : Gagal update data!", Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> map = new HashMap<>();
                map.put("id", month);
                map.put("token", inputToken.getText().toString());
                map.put("sisa", "0");
                map.put("mode", "manual");
                return map;

            }
        };
        AppController.getInstance().addToRequestQueue(updateReq);
    }

    public void getBulan(){
            Date date = new Date();
            LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            month = Integer.toString(localDate.getMonthValue());
            bulan = localDate.getMonthValue();
            System.out.println(month);
    }
}
