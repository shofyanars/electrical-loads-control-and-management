package com.telkomuniversity.emonitoring;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.telkomuniversity.emonitoring.Util.AppController;
import com.telkomuniversity.emonitoring.Util.ServerAPI;

import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Spliterator;

public class Mode_automatic extends AppCompatActivity {

    TextView tvpf, tvvoltage, tvarus1, tvarus2, tvarus3, tvarus4, tvkwh1, tvkwh2, tvkwh3, tvkwh4;

    private static final String TAG = "!!!!";
    private Button       btn_back_auto;

    private PendingIntent       pendingIntent11, pendingIntent12, pendingIntent13, pendingIntent14, pendingIntent15, pendingIntent21, pendingIntent22, pendingIntent23, pendingIntent24, pendingIntent25, pendingIntent31, pendingIntent32, pendingIntent33, pendingIntent34, pendingIntent35, pendingIntent41, pendingIntent42, pendingIntent43, pendingIntent44, pendingIntent45;

    public Integer[] idcheck        = new Integer[4];
    public Integer[] prioritycheck  = new Integer[4];
    public Integer[] statuscheck    = new Integer[4];
    public String[]  namacheck      = new String[4];

    public Integer[] bln            = new Integer[12];
    public Double[]  pake           = new Double[12];
    public Double[]  sisa           = new Double[12];
    public String[]  mode           = new String[12];

    public double    arus, kwh, tegangan, daya, reaktif, pf, tokenharian;
    public String    time, dated;
    public int ax, cx, sisahours, sisaminutes, bulannow;

    public Integer[] idData    = new Integer[5];
    public Double[]  arusData  = new Double[5];
    public String[]  timeData  = new String[5];
    public String[]  datedData = new String[5];
    public Double    arusP0, arusP1, arusP2, arusP3;

    long startTime=0L, timeInMilliseconds=0L, timeSwapBuff=0L, updateTime=0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode_automatic);
        getSupportActionBar().hide();

        btn_back_auto = findViewById(R.id.btn_back_automatic);

        btn_back_auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Mode_automatic.this, HomeMenu.class);
                startActivity(intent);
            }
        });

        bulan();
        sisaJam();

        startTime   = SystemClock.uptimeMillis();
        for(int i = 0; i<1; i++){
            loadDevice1();  // Device1
            loadDevice2();  // Device2
            loadDevice3();  // Device3
            loadDevice4();  // Device4
            loadDevice();   // relay status
            loadToken();    // token
            loadModbus();   // modbus
        }
        timeInMilliseconds = SystemClock.uptimeMillis()-startTime;
        Log.d("time", timeInMilliseconds+"ms timer stopwatch stopped ==========================================================================================");
    }

    public void automatic(View view) {
        Log.d(TAG, "Job started ==========================================================================================");

        Log.d("!!!!", "device1  > arus = " + arusData[0] + " waktu  : " + timeData[0] + " | tanggal : " + datedData[0]);
        Log.d("!!!!", "device2  > arus = " + arusData[1] + " waktu  : " + timeData[1] + " | tanggal : " + datedData[1]);
        Log.d("!!!!", "device3  > arus = " + arusData[2] + " waktu  : " + timeData[2] + " | tanggal : " + datedData[2]);
        Log.d("!!!!", "device4  > arus = " + arusData[3] + " waktu  : " + timeData[3] + " | tanggal : " + datedData[3]);

        Log.d("!!!!", "priority ke " + prioritycheck[0] + " id  : " + idcheck[0] + " | status : " + statuscheck[0] + " | Arus P1 " + arusP0);
        Log.d("!!!!", "priority ke " + prioritycheck[1] + " id  : " + idcheck[1] + " | status : " + statuscheck[1] + " | Arus P2 " + arusP1);
        Log.d("!!!!", "priority ke " + prioritycheck[2] + " id  : " + idcheck[2] + " | status : " + statuscheck[2] + " | Arus P3 " + arusP2);
        Log.d("!!!!", "priority ke " + prioritycheck[3] + " id  : " + idcheck[3] + " | status : " + statuscheck[3] + " | Arus P4 " + arusP3);
        Log.d("!!!!", "modbus   > pf = " + pf +  " | tegangan = " + tegangan); // + " | daya = " + daya + " | kwh = " + kwh + " | arus = " + arus + " | daya reaktif = " + reaktif +" | time = " + time + " | dated = " + dated);


        startTime   = SystemClock.uptimeMillis();
        Log.d("time","automode stopwatch started ==========================================================================================");

        tokenharian = pake[bulannow]/30;
        Log.d("!!!!", "TOKEN = " + tokenharian);
        Double watt1, watt2, watt3, watt4;
        watt1 = (arusP0*tegangan*pf)/1000;  // kW bukan kWh
        watt2 = (arusP1*tegangan*pf)/1000;  // kW bukan kWh
        watt3 = (arusP2*tegangan*pf)/1000;  // kW bukan kWh
        watt4 = (arusP3*tegangan*pf)/1000;  // kW bukan kWh

        // 1
        if (watt1*sisahours <= tokenharian){
            Log.d("!!!!", "DAYA = " + watt1 + " | kwh = " + watt1*sisahours + " E1 = nyala hingga pukul 24");
            // device 1 nyala
            updateData(String.valueOf(idcheck[0]), "1",String.valueOf(prioritycheck[0]), String.valueOf(namacheck[0]));

            // set alarm notif 5 menit sebelum
            Calendar cal11 = Calendar.getInstance();
            Intent alarmIntent11 = new Intent(Mode_automatic.this, AutomaticMode.class);
            alarmIntent11.putExtra("Message", "Mode automatic akan dimatikan 5 menit lagi!");
            cal11.set(Calendar.HOUR_OF_DAY, 23);
            cal11.set(Calendar.MINUTE, 55);
            cal11.set(Calendar.SECOND, 0);
            pendingIntent11 = PendingIntent.getBroadcast(Mode_automatic.this, 16, alarmIntent11, 0);
            AlarmManager manager11 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            manager11.setExact(AlarmManager.RTC_WAKEUP, cal11.getTimeInMillis(), pendingIntent11);

            /*
            // set alarm manager matikan saat jam yang ditentukan
            Calendar cal12 = Calendar.getInstance();
            Intent alarmIntent12 = new Intent(Mode_automatic.this, AutomaticMode.class);
            alarmIntent12.putExtra("Message", "Device " + namacheck[0] +" dimatikan!");
            alarmIntent12.putExtra("id", String.valueOf(idcheck[0]));
            alarmIntent12.putExtra("name", String.valueOf(namacheck[0]));
            alarmIntent12.putExtra("status", "0");
            alarmIntent12.putExtra("priority", String.valueOf(prioritycheck[0]));
            cal12.set(Calendar.HOUR_OF_DAY, 24);
            cal12.set(Calendar.MINUTE, 0);
            cal12.set(Calendar.SECOND, 0);
            pendingIntent12 = PendingIntent.getBroadcast(Mode_automatic.this, 17, alarmIntent12, 0);
            AlarmManager manager12 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            manager12.setExact(AlarmManager.RTC_WAKEUP, cal12.getTimeInMillis(), pendingIntent12);
            */
        }
        else {
            int hour = (int) (tokenharian/watt1);
            // matikan device 2 3 dan 4
            if (hour <= 0){
                updateData(String.valueOf(idcheck[0]), "0",String.valueOf(prioritycheck[0]), String.valueOf(namacheck[0]));
                Log.d("!!!!", "DAYA = " + watt2+ " | kwh = " + watt2*sisahours + " E1 = akan mati");

                // immidiately
                Calendar cal13 = Calendar.getInstance();
                Intent alarmIntent13 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent13.putExtra("Message", "Device " + namacheck[0] +" dimatikan!");
                cal13.add(Calendar.SECOND, 8);
                pendingIntent13 = PendingIntent.getBroadcast(Mode_automatic.this, 18, alarmIntent13, 0);
                AlarmManager manager13 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager13.setExact(AlarmManager.RTC_WAKEUP, cal13.getTimeInMillis(), pendingIntent13);
            }
            else {
                updateData(String.valueOf(idcheck[0]), "1",String.valueOf(prioritycheck[0]), String.valueOf(namacheck[0]));
                Log.d("!!!!", "DAYA = " + watt1+ " | kwh = " + watt1*sisahours + " E1 = akan mati " + hour + " jam lagi");

                // set alarm warning 5 menit sebelum
                Calendar cal14 = Calendar.getInstance();
                Intent alarmIntent14 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent14.putExtra("Message", "Device " + namacheck[0] +" akan dimatikan 5 menit lagi!");
                cal14.add(Calendar.HOUR_OF_DAY, (hour-1));
                cal14.add(Calendar.MINUTE, 55);
                cal14.add(Calendar.SECOND, 0);
                pendingIntent14 = PendingIntent.getBroadcast(Mode_automatic.this, 19, alarmIntent14, 0);
                AlarmManager manager14 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager14.setExact(AlarmManager.RTC_WAKEUP, cal14.getTimeInMillis(), pendingIntent14);

                // set alarm manager matikan 'hour' jam lagi
                Calendar cal15 = Calendar.getInstance();
                Intent alarmIntent15 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent15.putExtra("Message", "Device " + namacheck[0] +" dimatikan!");
                alarmIntent15.putExtra("id", String.valueOf(idcheck[0]));
                alarmIntent15.putExtra("name", String.valueOf(namacheck[0]));
                alarmIntent15.putExtra("status", "0");
                alarmIntent15.putExtra("priority", String.valueOf(prioritycheck[0]));
                cal15.add(Calendar.HOUR_OF_DAY, hour);
                cal15.add(Calendar.MINUTE, 0);
                cal15.add(Calendar.SECOND, 0);
                pendingIntent15 = PendingIntent.getBroadcast(Mode_automatic.this, 20, alarmIntent15, 0);
                AlarmManager manager15 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager15.setExact(AlarmManager.RTC_WAKEUP, cal15.getTimeInMillis(), pendingIntent15);
            }
        }

        // 2
        if (watt2*sisahours <= (tokenharian - (watt1*sisahours))){
            Log.d("!!!!", "DAYA = " + watt2 + " | kwh = " + watt2*sisahours + " E2 = nyala hingga pukul 24");
            // device 2 nyala
            updateData(String.valueOf(idcheck[1]), "1", String.valueOf(prioritycheck[1]), String.valueOf(namacheck[1]));

            // set alarm notif 5 menit sebelum
            Calendar cal21 = Calendar.getInstance();
            Intent alarmIntent21 = new Intent(Mode_automatic.this, AutomaticMode.class);
            alarmIntent21.putExtra("Message", "Mode automatic akan dimatikan 5 menit lagi!");
            cal21.set(Calendar.HOUR_OF_DAY, 23);
            cal21.set(Calendar.MINUTE, 55);
            cal21.set(Calendar.SECOND, 0);
            pendingIntent21 = PendingIntent.getBroadcast(Mode_automatic.this, 11, alarmIntent21, 0);
            AlarmManager manager21 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            manager21.setExact(AlarmManager.RTC_WAKEUP, cal21.getTimeInMillis(), pendingIntent21);

            /*
            // set alarm manager matikan saat jam yang ditentukan
            Calendar cal22 = Calendar.getInstance();
            Intent alarmIntent22 = new Intent(Mode_automatic.this, AutomaticMode.class);
            alarmIntent22.putExtra("Message", "Device " + namacheck[1] +" dimatikan!");
            alarmIntent22.putExtra("id", String.valueOf(idcheck[1]));
            alarmIntent22.putExtra("name", String.valueOf(namacheck[1]));
            alarmIntent22.putExtra("status", "0");
            alarmIntent22.putExtra("priority", String.valueOf(prioritycheck[1]));
            cal22.set(Calendar.HOUR_OF_DAY, 24);
            cal22.set(Calendar.MINUTE, 0);
            cal22.set(Calendar.SECOND, 0);
            pendingIntent22 = PendingIntent.getBroadcast(Mode_automatic.this, 12, alarmIntent22, 0);
            AlarmManager manager22 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            manager22.setExact(AlarmManager.RTC_WAKEUP, cal22.getTimeInMillis(), pendingIntent22);
            */
        }
        else
        {
            int hour = (int) (((tokenharian-(watt1*sisahours))/watt2));
            if (hour <= 0)
            {
                // matikan device 2
                updateData(String.valueOf(idcheck[1]), "0", String.valueOf(prioritycheck[1]), String.valueOf(namacheck[1]));
                Log.d("!!!!", "DAYA = " + watt2+ " | kwh = " + watt2*sisahours + " E2 = akan mati");

                // immidiately
                Calendar cal23 = Calendar.getInstance();
                Intent alarmIntent23 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent23.putExtra("Message", "Device " + namacheck[1] +" dimatikan!");
                cal23.add(Calendar.SECOND, 5);
                pendingIntent23 = PendingIntent.getBroadcast(Mode_automatic.this, 13, alarmIntent23, 0);
                AlarmManager manager23 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager23.setExact(AlarmManager.RTC_WAKEUP, cal23.getTimeInMillis(), pendingIntent23);
            }
            else {
                updateData(String.valueOf(idcheck[1]), "1", String.valueOf(prioritycheck[1]), String.valueOf(namacheck[1]));
                Log.d("!!!!", "DAYA = " + watt2+ " | kwh = " + watt2*sisahours + " E2 = akan mati " + hour + " jam lagi");

                // set alarm warning 5 menit sebelum
                Calendar cal24 = Calendar.getInstance();
                Intent alarmIntent24 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent24.putExtra("Message", "Device " + namacheck[1] +" akan dimatikan 5 menit lagi!");
                cal24.add(Calendar.HOUR_OF_DAY, (hour-1));
                cal24.add(Calendar.MINUTE, 55);
                cal24.add(Calendar.SECOND, 0);
                pendingIntent24 = PendingIntent.getBroadcast(Mode_automatic.this, 14, alarmIntent24, 0);
                AlarmManager manager24 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager24.setExact(AlarmManager.RTC_WAKEUP, cal24.getTimeInMillis(), pendingIntent24);

                // set alarm manager matikan 'hour' jam lagi
                Calendar cal25 = Calendar.getInstance();
                Intent alarmIntent25 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent25.putExtra("Message", "Device " + namacheck[1] +" dimatikan!");
                alarmIntent25.putExtra("id", String.valueOf(idcheck[1]));
                alarmIntent25.putExtra("name", String.valueOf(namacheck[1]));
                alarmIntent25.putExtra("status", "0");
                alarmIntent25.putExtra("priority", String.valueOf(prioritycheck[1]));
                cal25.add(Calendar.HOUR_OF_DAY, hour);
                cal25.add(Calendar.MINUTE, 0);
                cal25.add(Calendar.SECOND, 0);
                pendingIntent25 = PendingIntent.getBroadcast(Mode_automatic.this, 15, alarmIntent25, 0);
                AlarmManager manager25 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager25.setExact(AlarmManager.RTC_WAKEUP, cal25.getTimeInMillis(), pendingIntent25);
            }
        }

        // 3
        if (watt3*sisahours <= (tokenharian - (watt1*sisahours)-(watt2*sisahours))){
            Log.d("!!!!", "DAYA = " + watt3 + " | kwh = " + watt3*sisahours + " E3 = nyala hingga pukul 24");
            // device 1 2 dan 3 nyala
            updateData(String.valueOf(idcheck[2]), "1", String.valueOf(prioritycheck[2]), String.valueOf(namacheck[2]));

            // set alarm notif 5 menit sebelum
            Calendar cal31 = Calendar.getInstance();
            Intent alarmIntent31 = new Intent(Mode_automatic.this, AutomaticMode.class);
            alarmIntent31.putExtra("Message", "Mode automatic akan dimatikan 5 menit lagi!");
            cal31.set(Calendar.HOUR_OF_DAY, 23);
            cal31.set(Calendar.MINUTE, 55);
            cal31.set(Calendar.SECOND, 0);
            pendingIntent31 = PendingIntent.getBroadcast(Mode_automatic.this, 6, alarmIntent31, 0);
            AlarmManager manager31 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            manager31.setExact(AlarmManager.RTC_WAKEUP, cal31.getTimeInMillis(), pendingIntent31);

            /*
            // set alarm manager matikan saat jam yang ditentukan
            Calendar cal32 = Calendar.getInstance();
            Intent alarmIntent32 = new Intent(Mode_automatic.this, AutomaticMode.class);
            alarmIntent32.putExtra("Message", "Device " + namacheck[2] +" dimatikan!");
            alarmIntent32.putExtra("id", String.valueOf(idcheck[2]));
            alarmIntent32.putExtra("name", String.valueOf(namacheck[2]));
            alarmIntent32.putExtra("status", "0");
            alarmIntent32.putExtra("priority", String.valueOf(prioritycheck[2]));
            cal32.set(Calendar.HOUR_OF_DAY, 24);
            cal32.set(Calendar.MINUTE, 0);
            cal32.set(Calendar.SECOND, 0);
            pendingIntent32 = PendingIntent.getBroadcast(Mode_automatic.this, 7, alarmIntent32, 0);
            AlarmManager manager32 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            manager32.setExact(AlarmManager.RTC_WAKEUP, cal32.getTimeInMillis(), pendingIntent32);
            */
        }
        else
        {
            int hour = (int) (((tokenharian-(watt1*sisahours)-(watt2*sisahours))/watt3));
            if (hour <= 0)
            {
                // matikan device 3
                updateData(String.valueOf(idcheck[2]), "0", String.valueOf(prioritycheck[2]), String.valueOf(namacheck[2]));
                Log.d("!!!!", "DAYA = " + watt3+ " | kwh = " + watt3*sisahours + " E3 = akan mati");

                // immidiately
                Calendar cal33 = Calendar.getInstance();
                Intent alarmIntent33 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent33.putExtra("Message", "Device " + namacheck[2] +" dimatikan!");
                cal33.add(Calendar.SECOND, 5);
                pendingIntent33 = PendingIntent.getBroadcast(Mode_automatic.this, 8, alarmIntent33, 0);
                AlarmManager manager33 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager33.setExact(AlarmManager.RTC_WAKEUP, cal33.getTimeInMillis(), pendingIntent33);
            }
            else {
                updateData(String.valueOf(idcheck[2]), "1", String.valueOf(prioritycheck[2]), String.valueOf(namacheck[2]));
                Log.d("!!!!", "DAYA = " + watt3+ " | kwh = " + watt3*sisahours + " E3 = akan mati " + hour + " jam lagi");

                // set alarm warning 5 menit sebelum
                Calendar cal34 = Calendar.getInstance();
                Intent alarmIntent34 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent34.putExtra("Message", "Device " + namacheck[2] +" akan dimatikan 5 menit lagi!");
                cal34.add(Calendar.HOUR_OF_DAY, (hour-1));
                cal34.add(Calendar.MINUTE, 55);
                cal34.add(Calendar.SECOND, 0);
                pendingIntent34 = PendingIntent.getBroadcast(Mode_automatic.this, 9, alarmIntent34, 0);
                AlarmManager manager34 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager34.setExact(AlarmManager.RTC_WAKEUP, cal34.getTimeInMillis(), pendingIntent34);

                // set alarm manager matikan 'hour' jam lagi
                Calendar cal35 = Calendar.getInstance();
                Intent alarmIntent35 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent35.putExtra("Message", "Device " + namacheck[2] +" dimatikan!");
                alarmIntent35.putExtra("id", String.valueOf(idcheck[2]));
                alarmIntent35.putExtra("name", String.valueOf(namacheck[2]));
                alarmIntent35.putExtra("status", "0");
                alarmIntent35.putExtra("priority", String.valueOf(prioritycheck[2]));
                cal35.add(Calendar.HOUR_OF_DAY, hour);
                cal35.add(Calendar.MINUTE, 0);
                cal35.add(Calendar.SECOND, 0);
                pendingIntent35 = PendingIntent.getBroadcast(Mode_automatic.this, 10, alarmIntent35, 0);
                AlarmManager manager35 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager35.setExact(AlarmManager.RTC_WAKEUP, cal35.getTimeInMillis(), pendingIntent35);
            }
        }

        // 4
        if (watt4*sisahours <= (tokenharian - (watt1*sisahours) - (watt2*sisahours) - (watt3*sisahours)))
        {
            Log.d("!!!!", "DAYA = " + watt4 + " | kwh = " + watt4*sisahours + " E4 = nyala hingga pukul 24 ");
            // device 4 nyala
            updateData(String.valueOf(idcheck[3]), "1", String.valueOf(prioritycheck[3]), String.valueOf(namacheck[3]));

            // set alarm notif 5 menit sebelum
            Calendar cal41 = Calendar.getInstance();
            Intent alarmIntent41 = new Intent(Mode_automatic.this, AutomaticMode.class);
            alarmIntent41.putExtra("Message", "Mode automatic akan dimatikan 5 menit lagi!");
            cal41.set(Calendar.HOUR_OF_DAY, 23);
            cal41.set(Calendar.MINUTE, 55);
            cal41.set(Calendar.SECOND, 0);
            pendingIntent41 = PendingIntent.getBroadcast(Mode_automatic.this, 1, alarmIntent41, 0);
            AlarmManager manager41 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            manager41.setExact(AlarmManager.RTC_WAKEUP, cal41.getTimeInMillis(), pendingIntent41);

            /*
            // set alarm manager matikan saat jam yang ditentukan
            Calendar cal42 = Calendar.getInstance();
            Intent alarmIntent42 = new Intent(Mode_automatic.this, AutomaticMode.class);
            alarmIntent42.putExtra("Message", "Device " + namacheck[3] +" dimatikan!");
            alarmIntent42.putExtra("id", String.valueOf(idcheck[3]));
            alarmIntent42.putExtra("name", String.valueOf(namacheck[3]));
            alarmIntent42.putExtra("status", "0");
            alarmIntent42.putExtra("priority", String.valueOf(prioritycheck[3]));
            cal42.set(Calendar.HOUR_OF_DAY, 24);
            cal42.set(Calendar.MINUTE, 0);
            cal42.set(Calendar.SECOND, 0);
            pendingIntent42 = PendingIntent.getBroadcast(Mode_automatic.this, 2, alarmIntent42, 0);
            AlarmManager manager42 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            manager42.setExact(AlarmManager.RTC_WAKEUP, cal42.getTimeInMillis(), pendingIntent42);
            */

        }
        else
        {
            int hour = (int) (((tokenharian-(watt1*sisahours)-(watt2*sisahours)-(watt3*sisahours))/watt4));
            if (hour <= 0)
            {
                // matikan device 4
                updateData(String.valueOf(idcheck[3]), "0", String.valueOf(prioritycheck[3]), String.valueOf(namacheck[3]));
                Log.d("!!!!", "DAYA = " + watt4 + " | kwh = " + watt4*sisahours + " E4 = akan mati");

                // immidiately
                Calendar cal43 = Calendar.getInstance();
                Intent alarmIntent43 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent43.putExtra("Message", "Device " + namacheck[3] +" dimatikan!");
                cal43.add(Calendar.SECOND, 5);
                pendingIntent43 = PendingIntent.getBroadcast(Mode_automatic.this, 3, alarmIntent43, 0);
                AlarmManager manager43 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager43.setExact(AlarmManager.RTC_WAKEUP, cal43.getTimeInMillis(), pendingIntent43);
            }
            else {
                updateData(String.valueOf(idcheck[3]), "1", String.valueOf(prioritycheck[3]), String.valueOf(namacheck[3]));
                Log.d("!!!!", "DAYA = " + watt4+ " | kwh = " + watt4*sisahours + " E4 = akan mati " + hour + " jam lagi");

                // set alarm warning 5 menit sebelum
                Calendar cal44 = Calendar.getInstance();
                Intent alarmIntent44 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent44.putExtra("Message", "Device " + namacheck[3] +" akan dimatikan 5 menit lagi!");
                cal44.add(Calendar.HOUR_OF_DAY, (hour-1));
                cal44.add(Calendar.MINUTE, 55);
                cal44.add(Calendar.SECOND, 0);
                pendingIntent44 = PendingIntent.getBroadcast(Mode_automatic.this, 4, alarmIntent44, 0);
                AlarmManager manager44 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager44.setExact(AlarmManager.RTC_WAKEUP, cal44.getTimeInMillis(), pendingIntent44);

                // set alarm manager matikan 'hour' jam lagi
                Calendar cal45 = Calendar.getInstance();
                Intent alarmIntent45 = new Intent(Mode_automatic.this, AutomaticMode.class);
                alarmIntent45.putExtra("Message", "Device " + namacheck[3] +" dimatikan!");
                alarmIntent45.putExtra("id", String.valueOf(idcheck[3]));
                alarmIntent45.putExtra("name", String.valueOf(namacheck[3]));
                alarmIntent45.putExtra("status", "0");
                alarmIntent45.putExtra("priority", String.valueOf(prioritycheck[3]));
                cal45.add(Calendar.HOUR_OF_DAY, hour);
                cal45.add(Calendar.MINUTE, 0);
                cal45.add(Calendar.SECOND, 0);
                pendingIntent45 = PendingIntent.getBroadcast(Mode_automatic.this, 5, alarmIntent45, 0);
                AlarmManager manager45 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                manager45.setExact(AlarmManager.RTC_WAKEUP, cal45.getTimeInMillis(), pendingIntent45);
            }
        }
        timeInMilliseconds = SystemClock.uptimeMillis()-startTime;
        Log.d("time", timeInMilliseconds+"ms timer stopwatch stopped ==========================================================================================");
    }

    public void manual(View view) {

        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        if (pendingIntent11 != null){
            manager.cancel(pendingIntent11);
        }
        if (pendingIntent12 != null){
            manager.cancel(pendingIntent12);
        }
        if (pendingIntent13 != null){
            manager.cancel(pendingIntent13);
        }
        if (pendingIntent14 != null){
            manager.cancel(pendingIntent14);
        }
        if (pendingIntent15 != null){
            manager.cancel(pendingIntent15);
        }
        if (pendingIntent21 != null){
            manager.cancel(pendingIntent21);
        }
        if (pendingIntent22 != null){
            manager.cancel(pendingIntent22);
        }
        if (pendingIntent23 != null){
            manager.cancel(pendingIntent23);
        }
        if (pendingIntent24 != null){
            manager.cancel(pendingIntent24);
        }
        if (pendingIntent25 != null){
            manager.cancel(pendingIntent25);
        }
        if (pendingIntent31 != null){
            manager.cancel(pendingIntent31);
        }
        if (pendingIntent32 != null){
            manager.cancel(pendingIntent32);
        }
        if (pendingIntent33 != null){
            manager.cancel(pendingIntent33);
        }
        if (pendingIntent34 != null){
            manager.cancel(pendingIntent34);
        }
        if (pendingIntent35 != null){
            manager.cancel(pendingIntent35);
        }
        if (pendingIntent41 != null){
            manager.cancel(pendingIntent41);
        }
        if (pendingIntent42 != null){
            manager.cancel(pendingIntent42);
        }
        if (pendingIntent43 != null){
            manager.cancel(pendingIntent43);
        }
        if (pendingIntent44 != null){
            manager.cancel(pendingIntent44);
        }
        if (pendingIntent45 != null){
            manager.cancel(pendingIntent45);
        }

        //close existing/current notifications
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(1);
        notificationManager.cancelAll();

        Log.d(TAG, "Manual Mode Activated ==========================================================================================");
    }

    private void loadDevice()
    {
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.URL_VIEW, null,
                response -> {
                    //Log.d("volley", "response : " + response.toString());

                    TampilData td = new TampilData();

                    for(int i = 0; i < response.length(); i++)
                    {
                        try
                        {
                            ax = 0;
                            JSONObject data = response.getJSONObject(i);
                            int id       = Integer.parseInt(data.getString("id"));
                            int priority = Integer.parseInt(data.getString("priority"));
                            int status   = Integer.parseInt(data.getString("status"));
                            String nama  = data.getString("nama");
                            td.isiData(id, status, priority, nama);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    td.showData();
                },
                error -> Log.d("volley", "error : " + error.getMessage()));
        AppController.getInstance().addToRequestQueue(reqData);
    }

    private void loadToken()
    {
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.URL_TOKEN_VIEW, null,
                response -> {
                    //Log.d("volley", "response : " + response.toString());

                    TampilDataToken toks = new TampilDataToken();

                    for(int i = 0; i < response.length(); i++)
                    {
                        try
                        {
                            cx = 0;
                            JSONObject data = response.getJSONObject(i);
                            int    id       = Integer.parseInt(data.getString("id"));
                            Double token    = Double.parseDouble(data.getString("token"));
                            Double sisa     = Double.parseDouble(data.getString("sisa"));
                            String mode     = data.getString("mode");
                            toks.isiData(id,token,sisa, mode);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    toks.showData();
                },
                error -> Log.d("volley", "error : " + error.getMessage()));
        AppController.getInstance().addToRequestQueue(reqData);
    }

    private void loadModbus()
    {
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.LAST_MODBUS, null,
                response -> {
                    //Log.d("volley", "response : " + response.toString());

                    for(int i = 0; i < response.length(); i++)
                    {
                        try
                        {
                            JSONObject data = response.getJSONObject(i);
                            arus        = Double.parseDouble(data.getString("arus"));
                            kwh         = Double.parseDouble(data.getString("kwh"));
                            tegangan    = Double.parseDouble(data.getString("tegangan"));
                            daya        = Double.parseDouble(data.getString("daya"));
                            reaktif     = Double.parseDouble(data.getString("reaktif"));
                            pf          = Double.parseDouble(data.getString("pf"));
                            time        = data.getString("time");
                            dated       = data.getString("dated");
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                error -> Log.d("volley", "error : " + error.getMessage()));
        AppController.getInstance().addToRequestQueue(reqData);
    }

    private void loadDevice1()
    {
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.LAST_DEVICE1, null,
                response -> {
                    //Log.d("volley", "response : " + response.toString());

                    for(int i = 0; i < response.length(); i++)
                    {
                        try
                        {
                            JSONObject data = response.getJSONObject(i);
                            idData[0]    = Integer.parseInt(data.getString("id"));
                            arusData[0]  = Double.parseDouble(data.getString("arus"));
                            timeData[0]  = data.getString("time");
                            datedData[0] = data.getString("dated");
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                error -> Log.d("volley", "error : " + error.getMessage()));
        AppController.getInstance().addToRequestQueue(reqData);
    }

    private void loadDevice2()
    {
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.LAST_DEVICE2, null,
                response -> {
                    //Log.d("volley", "response : " + response.toString());

                    for(int i = 0; i < response.length(); i++)
                    {
                        try
                        {
                            JSONObject data = response.getJSONObject(i);
                            idData[1]    = Integer.parseInt(data.getString("id"));
                            arusData[1]  = Double.parseDouble(data.getString("arus"));
                            timeData[1]  = data.getString("time");
                            datedData[1] = data.getString("dated");
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                error -> Log.d("volley", "error : " + error.getMessage()));
        AppController.getInstance().addToRequestQueue(reqData);
    }

    private void loadDevice3()
    {
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.LAST_DEVICE3, null,
                response -> {
                    //Log.d("volley", "response : " + response.toString());

                    for(int i = 0; i < response.length(); i++)
                    {
                        try
                        {
                            JSONObject data = response.getJSONObject(i);
                            idData[2]    = Integer.parseInt(data.getString("id"));
                            arusData[2]  = Double.parseDouble(data.getString("arus"));
                            timeData[2]  = data.getString("time");
                            datedData[2] = data.getString("dated");
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                error -> Log.d("volley", "error : " + error.getMessage()));
        AppController.getInstance().addToRequestQueue(reqData);
    }

    private void loadDevice4()
    {
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.LAST_DEVICE4, null,
                response -> {
                    //Log.d("volley", "response : " + response.toString());

                    for(int i = 0; i < response.length(); i++)
                    {
                        try
                        {
                            JSONObject data = response.getJSONObject(i);
                            idData[3]    = Integer.parseInt(data.getString("id"));
                            arusData[3]  = Double.parseDouble(data.getString("arus"));
                            timeData[3]  = data.getString("time");
                            datedData[3] = data.getString("dated");
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                error -> Log.d("volley", "error : " + error.getMessage()));
        AppController.getInstance().addToRequestQueue(reqData);
    }

    // Load Device
    class Devices {
        public Integer id, priority, status;
        public String  nama;

        public Devices(Integer id, Integer status, Integer priority, String nama)
        {
            this.id         = id;
            this.priority   = priority;
            this.status     = status;
            this.nama       = nama;
        }

        // 1
        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        // 2
        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        // 3
        public Integer getPriority() {
            return priority;
        }

        public void setPriority(Integer priority) {
            this.priority = priority;
        }

        public String getNama() {
            return nama;
        }

        public void setNama(String priority) {
            this.nama = nama;
        }
    }

    // Load Device
    public class TampilData {
        public ArrayList<Devices> device;

        public TampilData() {
            //instansiasi
            device = new ArrayList<Devices>();
        }

        public void isiData(int id, int status, int priority, String nama) {
            device.add(new Devices(id, status, priority, nama));
            device.sort((device1, device2) -> device1.getPriority() - device2.getPriority());
            device.sort(Comparator.comparingInt(Devices::getPriority));
            Spliterator<Devices> split = device.spliterator();
            split.forEachRemaining(u -> TampilData.this.print(u));
        }

        public void print(Devices u)
        {
            idcheck[ax]       = u.id;
            statuscheck[ax]   = u.status;
            prioritycheck[ax] = u.priority;
            namacheck[ax]     = u.nama;

            if (idcheck[ax] == 1){
                arusP0 = arusData[ax];
            }
            else if (idcheck[ax] == 2){
                arusP1 = arusData[ax];
            }
            else if (idcheck[ax] == 3){
                arusP2 = arusData[ax];
            }
            else if (idcheck[ax] == 4){
                arusP3 = arusData[ax];
            }
            else
            {
                Log.d("error", "error input data!");
            }
            ax++;
        }

        public void showData() {
            for (Devices devicee : device) {
                //Log.d("volley", " call : " +  devicee.getId() + " | " +  devicee.getStatus() + " | " + devicee.getPriority() + " | " + devicee.getNama());
            }
        }
    }

    // Load Token
    class Token {

        public Integer idT;
        public Double tokenT;
        public Double sisaT;
        String modeT;

        public Token(Integer idT, Double tokenT, Double sisaT, String modeT)
        {
            this.idT    = idT;
            this.tokenT = tokenT;
            this.sisaT  = sisaT;
            this.modeT  = modeT;
        }

        // 1
        public Integer getIdT() {
            return idT;
        }

        public void setIdT(Integer idT) {
            this.idT = idT;
        }


        // 2
        public Double getTokenT() {
            return tokenT;
        }

        public void setTokenT(Double tokenT) {
            this.tokenT = tokenT;
        }

        public Double getSisaT() {
            return sisaT;
        }

        public void setUsage(Double sisaT) {
            this.sisaT = sisaT;
        }

        public String getModeT() {
            return modeT;
        }

        public void setModeT(String ModeT) {
            this.modeT = modeT;
        }

    }

    public class TampilDataToken {

        public ArrayList<Token> token;

        public TampilDataToken()
        {
            token = new ArrayList <Token>();
        }
        public void isiData (int idT, Double tokenT, Double sisaT, String modeT)
        {
            token.add(new Token (idT,tokenT,sisaT, modeT));
            Spliterator<Token> tiks = token.spliterator();
            tiks.forEachRemaining(u -> TampilDataToken.this.pisah(u));
        }

        public void pisah(Token u)
        {
            bln[cx]     = u.idT;
            pake[cx]    = u.tokenT;
            sisa[cx]    = u.sisaT;
            mode[cx]    = u.modeT;
            cx++;
        }

        public void showData(){
            for (Token devicee:token){
                //Log.d("volley", "call : " + devicee.getIdT() + " | " + devicee.getTokenT() + " | " +  devicee.getSisaT() + " | " +  devicee.getModeT());
            }
        }
    }

    public void sisaJam(){
        java.util.Date date  = new java.util.Date();
        java.sql.Timestamp timestamp1 = new java.sql.Timestamp(date.getTime());

        Calendar mid = Calendar.getInstance();
        mid.set(Calendar.HOUR_OF_DAY, 24);
        mid.set(Calendar.MINUTE, 0);
        java.sql.Timestamp timestamp2 = new Timestamp(mid.getTime().getTime());

        long milliseconds = timestamp2.getTime() - timestamp1.getTime();
        int seconds = (int) milliseconds / 1000;

        // calculate hours minutes and seconds
        sisahours = seconds / 3600;
        if (sisahours<1){
            sisahours = 1;
        }
        sisaminutes = (seconds % 3600) / 60;

        Log.d("!!!!", String.valueOf(timestamp1));
        Log.d("!!!!", String.valueOf(timestamp2));
        Log.d("!!!!", "Difference: ");
        Log.d("!!!!", " Hours: " + sisahours);
        Log.d("!!!!", " Minutes: " + sisaminutes);
    }

    public void bulan(){
        Date date = new Date();
        LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        int bulan = localDate.getMonthValue();
        bulannow = bulan - 1;
    }

    private void updateData(String id, String status, String priority, String nama)
    {
        StringRequest updateReq = new StringRequest(Request.Method.POST, ServerAPI.URL_UPDATE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try
                        {
                            JSONObject res = new JSONObject(response);
                        }
                        catch(JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> map = new HashMap<>();
                map.put("id", id);
                map.put("nama", nama);
                map.put("status", status);
                map.put("priority", priority);
                return map;
            }
        };
        AppController.getInstance().addToRequestQueue(updateReq);
    }
}
