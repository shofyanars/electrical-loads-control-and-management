package com.telkomuniversity.emonitoring;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.telkomuniversity.emonitoring.Adapter.AdapterData;
import com.telkomuniversity.emonitoring.Model.ModelData;
import com.telkomuniversity.emonitoring.Util.AppController;
import com.telkomuniversity.emonitoring.Util.ServerAPI;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class mode_electricity extends AppCompatActivity {

    RecyclerView mRecyclerView;

    /* Adapter dan Manager esensial untuk Recyclerview, perintah dibuat setelah
    membuat AppController, Modeldata dan Adapter Data */
    RecyclerView.Adapter        mAdapter;
    RecyclerView.LayoutManager  mManager;

    // list dibuat untuk menampung data yang sudah di request
    List<ModelData>             mItems;

    Button                      Back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode_electricity);

        getSupportActionBar().hide();

        Back            = findViewById(R.id.btn_back_manual);
        mRecyclerView   = (RecyclerView) findViewById(R.id.RecyclerViewTemp);
        mItems          = new ArrayList<>();

        loadJson();

        mManager = new LinearLayoutManager(mode_electricity.this, LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mManager);
        mAdapter = new AdapterData(mode_electricity.this, mItems);
        mRecyclerView.setAdapter(mAdapter);

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mode_electricity.this, HomeMenu.class);
                startActivity(intent);
            }
        });
    }

    private void loadJson()
    {
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.URL_VIEW, null,
                new Response.Listener<JSONArray>()
                {
                    @Override
                    public void onResponse(JSONArray response)
                    {
                        Log.d("volley", "response : " + response.toString() + '\n');
                        for(int i = 0; i < response.length(); i++)
                        {
                            try
                            {
                                JSONObject data = response.getJSONObject(i);
                                ModelData  md   = new ModelData();
                                md.setId(data.getString("id"));
                                md.setNama(data.getString("nama"));
                                md.setStatus(data.getString("status"));
                                md.setPriority(data.getString("priority"));
                                mItems.add(md);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        mAdapter.notifyDataSetChanged();
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Log.d("volley", "error : " + error.getMessage());
                    }
                });
        AppController.getInstance().addToRequestQueue(reqData);
    }
}
